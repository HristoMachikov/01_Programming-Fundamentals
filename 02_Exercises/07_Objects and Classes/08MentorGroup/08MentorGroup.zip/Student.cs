﻿namespace _08MentorGroup
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;

    public class Student
    {
        public string Name { get; set; }

        public List<DateTime> AllDates { get; set; }

        public List<string> Comments { get; set; }
    }
}
