﻿namespace _03CirclesIntersection
{
    public class Circle
    {
        public Point Center { get; set; }

        public int Radius { get; set; }
    }
}
