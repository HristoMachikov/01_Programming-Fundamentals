﻿namespace _10StudentGroups
{
    using System;
    using System.Collections.Generic;

    public class Student
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public DateTime Registration { get; set; }
    }
}
