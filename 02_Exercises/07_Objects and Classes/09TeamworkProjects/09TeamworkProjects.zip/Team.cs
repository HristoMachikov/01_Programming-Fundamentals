﻿namespace _09TeamworkProjects
{
    using System;
    using System.Collections.Generic;

    public class Team
    {
        public string TeamName { get; set; }

        public string Creator { get; set; }

        public List<string> Members { get; set; }
    }
}
